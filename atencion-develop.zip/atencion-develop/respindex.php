<?php
    header("Location: localhost/public_html/pai");
?>