<h3>Tiene una Nueva Derivación</h3>
<p><strong>Alumna : </strong>{{!!$alumna!!}}</p>
<p><strong>Curso  :</strong>{{!!$curso!!}}</p>